==== README ====
Thanks for using this ContractorMod.

This mod enable simulating a defined number of characters you control one by one during a solo game.

Following video shows a gameplay scenario using ContractorMod (recorded on a beta version on FS2013)
https://www.youtube.com/watch?v=l70WQdWoTy0


By default, 4 characters are available Alex, Bob, Chris et David.
At first loading of a map, they are located at the Career starting point.
When saving the game, characters location and vehicle is saved so they will be restored when loading the game.


Dafault key to swtich between characters are:
 - NEXT    : Tab
 - PREVIOUS: Shift + Tab
They can be changed but by default replaced the standard switch between vehicle since it's disable.


This mod is compatible with PassengerMod specialization and with CoursePlay and FollowMe mods.
So, for example, when using FollowMe, one character will be the Leader and another one the Follower.


Characters name and number of characters can be changed in ContractorMod.xml file for new games.
Once a game has been saved, they can be changed in ContractorMod.xml file present in related savegame folder.
